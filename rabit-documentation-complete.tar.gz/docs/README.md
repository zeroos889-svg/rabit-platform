# مستندات منصة رابِط - Rabit Platform Documentation

**الإصدار:** 1.0.0  
**التاريخ:** نوفمبر 2025  
**الفريق المؤسس:** صالح العقيل، منصور الجابر

---

## نظرة عامة

مرحباً بك في مستودع التوثيق الشامل لمنصة رابِط لإدارة الموارد البشرية. يحتوي هذا المستودع على جميع المستندات اللازمة للمطورين والمستخدمين والشركاء، متوفرة باللغتين العربية والإنجليزية.

## هيكل المستندات

```
docs/
├── README.md                    # هذا الملف
├── technical/                   # التوثيق الفني
│   ├── ar/                     # عربي
│   │   ├── installation-guide.md
│   │   ├── developer-guide.md
│   │   ├── api-documentation.md
│   │   └── database-schema.md
│   └── en/                     # English
│       ├── installation-guide.md
│       ├── developer-guide.md
│       ├── api-documentation.md
│       └── database-schema.md
├── user-guides/                # أدلة المستخدم
│   ├── ar/
│   │   ├── company-guide.md
│   │   ├── consultant-guide.md
│   │   ├── employee-guide.md
│   │   └── admin-guide.md
│   └── en/
│       ├── company-guide.md
│       ├── consultant-guide.md
│       ├── employee-guide.md
│       └── admin-guide.md
├── legal/                      # المستندات القانونية
│   ├── ar/
│   │   ├── terms-of-service.md
│   │   ├── privacy-policy.md
│   │   ├── cookie-policy.md
│   │   └── sla.md
│   └── en/
│       ├── terms-of-service.md
│       ├── privacy-policy.md
│       ├── cookie-policy.md
│       └── sla.md
├── business/                   # مستندات الأعمال
│   ├── ar/
│   │   ├── product-overview.md
│   │   ├── pricing-guide.md
│   │   ├── case-studies.md
│   │   └── faq.md
│   └── en/
│       ├── product-overview.md
│       ├── pricing-guide.md
│       ├── case-studies.md
│       └── faq.md
└── marketing/                  # المواد التسويقية
    ├── ar/
    │   ├── brochure.md
    │   ├── one-pager.md
    │   └── presentation.md
    └── en/
        ├── brochure.md
        ├── one-pager.md
        └── presentation.md
```

## 📚 التوثيق الفني (Technical Documentation)

### دليل التثبيت (Installation Guide)
- **العربي**: `technical/ar/installation-guide.md`
- **English**: `technical/en/installation-guide.md`

دليل شامل لتثبيت وتكوين منصة رابِط، يشمل:
- المتطلبات الأساسية (Hardware & Software)
- خطوات التثبيت التفصيلية
- إعداد قاعدة البيانات
- تكوين متغيرات البيئة
- التحقق من التثبيت
- استكشاف الأخطاء وحلها

### دليل المطور (Developer Guide)
- **العربي**: `technical/ar/developer-guide.md`
- **English**: `technical/en/developer-guide.md`

دليل شامل للمطورين يغطي:
- البنية المعمارية للمنصة
- هيكل المشروع التفصيلي
- تطوير Frontend (React + TypeScript)
- تطوير Backend (tRPC + Express)
- التعامل مع قاعدة البيانات (Drizzle ORM)
- التكامل مع الخدمات الخارجية
- معايير الكتابة والأمان
- الاختبار والأداء

### توثيق API (API Documentation)
- **العربي**: `technical/ar/api-documentation.md`
- **English**: `technical/en/api-documentation.md`

توثيق كامل لجميع APIs المتاحة (35+ API):
- نظام المصادقة (Authentication)
- إدارة الموظفين (Employees)
- نظام التوظيف (ATS)
- الاستشارات (Consultations)
- الدورات التدريبية (Courses)
- التقارير والإحصائيات

### توثيق قاعدة البيانات (Database Schema)
- **العربي**: `technical/ar/database-schema.md`
- **English**: `technical/en/database-schema.md`

وصف تفصيلي لهيكل قاعدة البيانات:
- 55 جدولاً مع الوصف الكامل
- العلاقات بين الجداول
- الفهارس والمفاتيح
- أمثلة على الاستعلامات

## 👥 أدلة المستخدم (User Guides)

### دليل الشركات (Company Guide)
- **العربي**: `user-guides/ar/company-guide.md`
- **English**: `user-guides/en/company-guide.md`

دليل شامل للشركات يشمل:
- إنشاء الحساب والبدء
- إدارة الموظفين
- نظام تتبع المتقدمين (ATS)
- التقارير والإحصائيات
- الإعدادات والتخصيص

### دليل المستشارين (Consultant Guide)
- **العربي**: `user-guides/ar/consultant-guide.md`
- **English**: `user-guides/en/consultant-guide.md`

دليل للمستشارين يغطي:
- التسجيل كمستشار
- إدارة الاستشارات
- جدولة المواعيد
- التقارير المالية

### دليل الموظفين (Employee Guide)
- **العربي**: `user-guides/ar/employee-guide.md`
- **English**: `user-guides/en/employee-guide.md`

دليل للموظفين يشمل:
- الوصول إلى البيانات الشخصية
- طلب الإجازات
- الحضور والانصراف
- الشهادات والوثائق

### دليل المدير (Admin Guide)
- **العربي**: `user-guides/ar/admin-guide.md`
- **English**: `user-guides/en/admin-guide.md`

دليل شامل لمدير النظام:
- إدارة المستخدمين
- إدارة الاشتراكات
- سجلات التدقيق
- الإعدادات المتقدمة

## ⚖️ المستندات القانونية (Legal Documents)

### الشروط والأحكام (Terms of Service)
- **العربي**: `legal/ar/terms-of-service.md`
- **English**: `legal/en/terms-of-service.md`

الشروط والأحكام الكاملة لاستخدام المنصة، متوافقة مع القوانين السعودية.

### سياسة الخصوصية (Privacy Policy)
- **العربي**: `legal/ar/privacy-policy.md`
- **English**: `legal/en/privacy-policy.md`

سياسة شاملة لحماية البيانات والخصوصية، متوافقة مع GDPR ونظام حماية البيانات الشخصية السعودي.

### سياسة الكوكيز (Cookie Policy)
- **العربي**: `legal/ar/cookie-policy.md`
- **English**: `legal/en/cookie-policy.md`

شرح تفصيلي لاستخدام ملفات تعريف الارتباط (Cookies) في المنصة.

### اتفاقية مستوى الخدمة (SLA)
- **العربي**: `legal/ar/sla.md`
- **English**: `legal/en/sla.md`

التزامات الخدمة ومستويات الأداء المضمونة.

## 💼 مستندات الأعمال (Business Documents)

### نظرة عامة على المنتج (Product Overview)
- **العربي**: `business/ar/product-overview.md`
- **English**: `business/en/product-overview.md`

وصف شامل للمنصة ومميزاتها وفوائدها للشركات.

### دليل الأسعار (Pricing Guide)
- **العربي**: `business/ar/pricing-guide.md`
- **English**: `business/en/pricing-guide.md`

تفاصيل الباقات والأسعار والمقارنات.

### دراسات الحالة (Case Studies)
- **العربي**: `business/ar/case-studies.md`
- **English**: `business/en/case-studies.md`

قصص نجاح العملاء والنتائج المحققة.

### الأسئلة الشائعة (FAQ)
- **العربي**: `business/ar/faq.md`
- **English**: `business/en/faq.md`

إجابات على الأسئلة الأكثر شيوعاً.

## 📢 المواد التسويقية (Marketing Materials)

### البروشور التسويقي (Brochure)
- **العربي**: `marketing/ar/brochure.md`
- **English**: `marketing/en/brochure.md`

مادة تسويقية شاملة للمنصة.

### الملخص التنفيذي (One-Pager)
- **العربي**: `marketing/ar/one-pager.md`
- **English**: `marketing/en/one-pager.md`

ملخص من صفحة واحدة للمنصة.

### العرض التقديمي (Presentation Deck)
- **العربي**: `marketing/ar/presentation.md`
- **English**: `marketing/en/presentation.md`

عرض تقديمي احترافي للمنصة.

## 🔍 البحث في المستندات

للبحث عن موضوع معين في جميع المستندات:

```bash
# البحث في المستندات العربية
grep -r "كلمة البحث" docs/*/ar/

# البحث في المستندات الإنجليزية
grep -r "search term" docs/*/en/

# البحث في جميع المستندات
grep -r "keyword" docs/
```

## 📝 المساهمة في التوثيق

إذا كنت ترغب في المساهمة في تحسين التوثيق:

1. اقرأ الوثيقة بعناية
2. حدد المشكلة أو التحسين المطلوب
3. اقترح التعديلات بوضوح
4. تأكد من الالتزام بالأسلوب المتبع

## 🌐 الوصول عبر الإنترنت

جميع المستندات متاحة أيضاً على:
- **الموقع الرسمي**: https://rabit.sa/docs
- **GitHub**: https://github.com/rabit-hr/rabit-platform/docs

## 📧 الدعم والمساعدة

للحصول على المساعدة أو الإبلاغ عن مشكلة في التوثيق:

- **البريد الإلكتروني**: docs@rabit.sa
- **الدعم الفني**: support@rabit.sa
- **الموقع**: https://rabit.sa/support

## 📊 إحصائيات التوثيق

| الفئة | عدد المستندات | الحالة |
|-------|---------------|--------|
| التوثيق الفني | 8 | ✅ مكتمل |
| أدلة المستخدم | 8 | ✅ مكتمل |
| المستندات القانونية | 8 | ✅ مكتمل |
| مستندات الأعمال | 8 | ✅ مكتمل |
| المواد التسويقية | 6 | ✅ مكتمل |
| **المجموع** | **38** | **✅ 100%** |

## 🔄 التحديثات

يتم تحديث هذه المستندات بشكل دوري مع كل إصدار جديد من المنصة. تأكد من الرجوع إلى أحدث إصدار دائماً.

**آخر تحديث**: نوفمبر 2025  
**الإصدار**: 1.0.0

---

## 📜 الترخيص

جميع المستندات محمية بحقوق النشر © 2025 منصة رابِط. جميع الحقوق محفوظة.

**ملاحظة**: السجل التجاري تحت الإصدار.

---

**الفريق المؤسس:**
- صالح العقيل - [LinkedIn](https://www.linkedin.com/in/saleh0alaqil)
- منصور الجابر - [LinkedIn](https://www.linkedin.com/in/mansouraljaber11a)
